import {useState} from 'react'
import {createSearchParams, useNavigate, useSearchParams} from 'react-router-dom'

/*
const getNum = (param: string | null, defaultValue: number | null) => {
  if (!param) {
    return defaultValue
  }

  return parseInt(param)
}
*/
export type initParam = {
  pageType: string
  sizeType: string
}

const useCustomMove = () => {
  const navigate = useNavigate()

  const [refresh, setRefresh] = useState(false)
  const [page, setPage] = useState('1')
  const [size, setSize] = useState('10')

  const queryDefault = createSearchParams({page, size}).toString()
  const [queryParams] = useSearchParams()

  const moveToList = (pageParam: initParam) => {
    let queryStr = ''

    if (pageParam) {
      const pageNum = pageParam.pageType

      const sizeNum = pageParam.sizeType

      queryStr = createSearchParams({page: pageNum, size: sizeNum}).toString()
    } else {
      queryStr = queryDefault
    }

    setRefresh(!refresh)
    navigate({pathname: `../list`, search: queryStr})
  }

  const moveToModify = (id: number) => {
    navigate({
      pathname: `../modify/${id}`,
      search: queryDefault, // 수정 시에 기존의 쿼리 스트링 유지를 위해
    })
  }

  return {moveToList, moveToModify, page, size, refresh}
}
export default useCustomMove
